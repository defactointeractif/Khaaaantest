﻿DROP TABLE [dbo].[khaaaantest_Contests]
DROP TABLE [dbo].[khaaaantest_Contestant]